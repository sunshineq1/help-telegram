@echo off
cd /d "%~dp0"
echo Server: http://localhost:8000  (close this window to stop)
start "" cmd /c "timeout /t 2 >nul & start http://localhost:8000"
python -m http.server 8000 2>nul || py -m http.server 8000
pause
