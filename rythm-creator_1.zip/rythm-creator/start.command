#!/bin/bash
cd "$(dirname "$0")"
echo "Server: http://localhost:8000  (Ctrl+C to stop)"
(sleep 1.5; open http://localhost:8000) &
python3 -m http.server 8000
